shopt -s expand_aliases
source .bash_aliases 